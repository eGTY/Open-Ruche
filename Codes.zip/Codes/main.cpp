// Importation of all libraries
#include <iostream>
#include "mbed.h"
#include "DS1820.h"
#include "Dht11.h"
#include "DavisAnemometer.h"
#include "HX711.h"

//Pin setup
#define MAX_PROBES      16
#define DATA_PIN        A0
DigitalOut gpo(D4);
Serial pc(PA_9, PA_10);
AnalogIn scaleRaw(A3);
HX711 scale(A3, D4);
DS1820* probe[MAX_PROBES];
static DavisAnemometer anemometer(A1 /* wind direction */, A2 /* wind speed */);
Dht11 sensor(PA_11); 

float calibration_factor = 10000; //-7050 worked for my 440lb max scale setup
int averageSamples = 10;=
int DS1820_temperature,DHT11_temp,DHT11_hum,ventDirection,ventVitesse;
float weight;
int num_devices = 0;

void DS1820_temp() {
    probe[0]->convertTemperature(true, DS1820::all_devices);  //Start temperature conversion, wait until ready
        for (int i = 0; i<num_devices; i++){
        DS1820_temperature = (int)probe[i]->temperature();
        printf("Device %d returns %3.1foC\r\n",i, probe[i]->temperature());   
         }   
        printf("\r\n");
        wait(1); 
}

void DHT11_Temp_Humidity() {
     sensor.read();
     DHT11_temp = sensor.getCelsius();
     DHT11_hum = sensor.getHumidity();
     printf("Dht11=temp %d,hum %d\r\n", DHT11_temp, DHT11_hum );
     wait(1);
    
    }
    
void Anemo() {
    ventDirection = anemometer.readWindDirection();
    ventVitesse = (int)anemometer.readWindSpeed();
    printf("DAVIS:   [drct] %d degree,  [speed] %d km/h\r\n", ventDirection, ventVitesse);
     wait_ms(3000);
    
}

void CapteurPoids(){ //Weight sensor function
          scale.setScale(calibration_factor); 
         weight = scale.getGram();
        float raw = scaleRaw.read();
       
        printf("\rReading: %d\n", (int)weight);
        printf("\rRaw Value: %.7f\n", raw);
        printf("\rcalibration_factor: %.2f\r\n", calibration_factor);
        wait(10 );
}

int main() {  
    // Initialize the probe array to DS1820 objects
    
    while(DS1820::unassignedProbe(DATA_PIN)) {
        probe[num_devices] = new DS1820(DATA_PIN);
        num_devices++;
        if (num_devices == MAX_PROBES)
            break;
    }
    
    printf("Found %d device(s)\r\n\n", num_devices);
    anemometer.enable();
     
    printf("Starting Scale");
    printf("HX711 calibration sketch");
    printf("Remove all weight from scale");
    printf("After readings begin, place known weight on scale"); 
      
    scale.setScale(5000);
    scale.tare(); //Reset the scale to 0
    
    float zero_factor = scale.averageValue(averageSamples); //Get a baseline reading
    printf("\rZero factor: %.4f\n" , zero_factor); //This can be 
    
    //Routine
    while(1) {
       DS1820_temp();
       DHT11_Temp_Humidity();
       Anemo();
       CapteurPoids();
       pc.printf("AT$SF=%02x%02x%02x%02x%02x%04x\r\n", DS1820_temperature,DHT11_temp,DHT11_hum,(int)weight,ventVitesse,ventDirection);
        
        wait(600); //One message every 10 minutes
    }
    
}

